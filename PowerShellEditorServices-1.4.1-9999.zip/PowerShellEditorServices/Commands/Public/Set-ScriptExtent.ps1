#
# Copyright (c) Microsoft. All rights reserved.
# Licensed under the MIT license. See LICENSE file in the project root for full license information.
#

function Set-ScriptExtent {
    <#
    .EXTERNALHELP ..\PowerShellEditorServices.Commands-help.xml
    #>
    [CmdletBinding(PositionalBinding=$false, DefaultParameterSetName='__AllParameterSets')]
    param(
        [Parameter(Position=0, Mandatory)]
        [psobject]
        $Text,

        [Parameter(Mandatory, ParameterSetName='AsString')]
        [switch]
        $AsString,

        [Parameter(Mandatory, ParameterSetName='AsArray')]
        [switch]
        $AsArray,

        [Parameter(ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [System.Management.Automation.Language.IScriptExtent]
        $Extent = (Find-Ast -AtCursor).Extent
    )
    begin {
        $fileContext = $psEditor.GetEditorContext().CurrentFile
        $extentList = New-Object System.Collections.Generic.List[Microsoft.PowerShell.EditorServices.FullScriptExtent]
    }
    process {
        if ($Extent -isnot [Microsoft.PowerShell.EditorServices.FullScriptExtent]) {
            $Extent = New-Object Microsoft.PowerShell.EditorServices.FullScriptExtent @(
                $fileContext,
                $Extent.StartOffset,
                $Extent.EndOffset)
        }
        $extentList.Add($Extent)
    }
    # Currently this kills the pipeline because we need to keep track and edit all extents for position tracking.
    # TODO: Consider queueing changes in a static property and adding a PassThru switch.
    end {
        switch ($PSCmdlet.ParameterSetName) {
            # Insert text as a single string expression.
            AsString {
                $Text = "'{0}'" -f $Text.Replace("'", "''")
            }
            # Create a string expression for each line, separated by a comma.
            AsArray {
                $newLine = [Environment]::NewLine
                $Text = "'" + ($Text.Replace("'", "''") -split '\r?\n' -join "',$newLine'") + "'"

                if ($Text.Split("`n", [StringSplitOptions]::RemoveEmptyEntries).Count -gt 1) {
                    $needsIndentFix = $true
                }
            }
        }

        foreach ($aExtent in $extentList) {
            $aText = $Text

            if ($needsIndentFix) {
                # I'd rather let PSSA handle this when there are more formatting options.
                $indentOffset = ' ' * ($aExtent.StartColumnNumber - 1)
                $aText = $aText -split '\r?\n' `
                                -join ([Environment]::NewLine + $indentOffset)
            }
            $differenceOffset = $aText.Length - $aExtent.Text.Length
            $scriptText       = $fileContext.GetText()

            $fileContext.InsertText($aText, $aExtent.BufferRange)

            $newText = $scriptText.Remove($aExtent.StartOffset, $aExtent.Text.Length).Insert($aExtent.StartOffset, $aText)

            $timeoutLoop = 0
            while ($fileContext.GetText() -ne $newText) {
                Start-Sleep -Milliseconds 30
                $timeoutLoop++

                if ($timeoutLoop -gt 20) {
                    $PSCmdlet.WriteDebug(('Timed out waiting for change at range {0}, {1}' -f $aExtent.StartOffset,
                                                                                              $aExtent.EndOffset))
                    break
                }
            }

            if ($differenceOffset) {
                $extentList.ForEach({
                    if ($args[0].StartOffset -ge $aExtent.EndOffset) {
                        $args[0].AddOffset($differenceOffset)
                    }
                })
            }
        }
    }
}
